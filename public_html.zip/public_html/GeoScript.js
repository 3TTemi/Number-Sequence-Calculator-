// response to when a1 radio button is pressed
function solve_a1()
{
    var a1 = document.getElementById("a1box");
    var an = document.getElementById("anbox");
    var n = document.getElementById("nbox");
    var r = document.getElementById("rbox");


    a1.style.display = "inline";
    an.style.display = "inline";
    n.style.display = "inline";
    r.style.display = "inline";


    an.style.display = 'inline';
    a1.style.display = "none";

}

// calculation for each variable in geometric sequence
function valueCalculation()
{


    var buttonClick = document.getElementById('buttoncalc');
    var a1value = document.getElementById("value_a1").value;
    var anvalue = document.getElementById("value_an").value;
    var nvalue = document.getElementById("value_n").value;
    var rvalue = document.getElementById("value_r").value;


    if (document.getElementById("radio_an").checked === true)
    {
        anvalue = ((+a1value) * (Math.pow(+rvalue, (+nvalue - 1))));
        if (isNaN(anvalue))
        {
            alert("Error: Invalid Input Entered. Please only enter Numbers!");
        } else
        {
            alert("The nth term of the sequence is " + anvalue);
        }
    }

    if (document.getElementById("radio_a1").checked === true)
    {
        a1value = ((+anvalue) / (Math.pow(+rvalue, (+nvalue - 1))));
        if (isNaN(a1value))
        {
            alert("Error: Invalid Input Entered. Please only enter Numbers!");
        } else
        {
            alert("The first term of the sequence is " + a1value);
        }
    }

    if (document.getElementById("radio_n").checked === true)
    {
        nvalue = (Math.log(+anvalue / +a1value) / Math.log(+rvalue)) + 1;
        if (isNaN(nvalue))
        {
            alert("Error: Invalid Input Entered. Please only enter Numbers!");
        } else
        {
            alert("The term position is " + nvalue);
        }
    }

    if (document.getElementById("radio_r").checked === true)
    {
        rvalue = Math.pow((+anvalue / +a1value), (1 / (+nvalue - 1)));
        if (isNaN(rvalue))
        {
            alert("Error: Invalid Input Entered. Please only enter Numbers!");
        } else
        {
            alert("The common ratio is " + rvalue);

        }
    }
    }
    
    // response to when n radio button is pressed
    function solve_n()
    {

        var a1 = document.getElementById("a1box");
        var an = document.getElementById("anbox");
        var n = document.getElementById("nbox");
        var r = document.getElementById("rbox");

        a1.style.display = "inline";
        an.style.display = "inline";
        n.style.display = "inline";
        r.style.display = "inline";

        an.style.display = 'inline';
        n.style.display = "none";

    }

// response to when r radio button is pressed
    function solve_r()
    {

        var a1 = document.getElementById("a1box");
        var an = document.getElementById("anbox");
        var n = document.getElementById("nbox");
        var r = document.getElementById("rbox");


        a1.style.display = "inline";
        an.style.display = "inline";
        n.style.display = "inline";
        r.style.display = "inline";

        an.style.display = 'inline';
        r.style.display = "none";
    }


// response to when an radio button is pressed
    function solve_an()
    {
        var a1 = document.getElementById("a1box");
        var an = document.getElementById("anbox");
        var n = document.getElementById("nbox");
        var r = document.getElementById("rbox");

        a1.style.display = "inline";
        an.style.display = "inline";
        n.style.display = "inline";
        r.style.display = "inline";

        an.style.display = 'none';

    }
    
