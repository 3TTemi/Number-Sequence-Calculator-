// response to when a1 radio button is pressed
function solve_a1()
{
    var a1 = document.getElementById("a1box");
    var an = document.getElementById("anbox");
    var n = document.getElementById("nbox");
    var d = document.getElementById("dbox");
   
    
    a1.style.display = "inline";
    an.style.display = "inline";
    n.style.display = "inline";
    d.style.display = "inline";

    
    an.style.display = 'inline'
    a1.style.display = "none";
    

}

// calculation for each variable in arithmetic sequence
function valueCalculation()
{


    var buttonClick = document.getElementById('buttoncalc');
    var a1value = document.getElementById("value_a1").value;
    var anvalue = document.getElementById("value_an").value;
    var nvalue = document.getElementById("value_n").value;
    var dvalue = document.getElementById("value_d").value;
        
    if (document.getElementById("radio_an").checked === true)
    {
        anvalue = (+a1value + ((+nvalue - 1) * +dvalue));

       if(isNaN(anvalue))
       {
           alert("Error: Invalid Input Entered. Please only enter Numbers!");
       }
       else
       {
           alert("The nth term of the sequence is " + anvalue);
       }
                 

    }
    
    if (document.getElementById("radio_a1").checked === true)
    {
       a1value = ((+nvalue - 1) * +dvalue) - anvalue;
       
        if(isNaN(a1value))
       {
           alert("Error: Invalid Input Entered. Please only enter Numbers!");
       }
       else
       {
          alert("The first term of the sequence is " + a1value);

       }
    }
    
    if (document.getElementById("radio_n").checked === true)
    {
        nvalue = ((+anvalue - +a1value) / +dvalue) + 1;
        
       if(isNaN(nvalue))
       {
           alert("Error: Invalid Input Entered. Please only enter Numbers!");
       }
       else
       {
           alert("The term position is " + nvalue);

       }
    }
    
    if (document.getElementById("radio_d").checked === true)
    {
        dvalue = (+anvalue - +a1value) / (+nvalue - 1);

        if(isNaN(dvalue))
       {
           alert("Error: Invalid Input Entered. Please only enter Numbers!");
       }
       else
       {
            alert("The common difference is " + dvalue);
       }

    }
    
}

// response to when n radio button is pressed
function solve_n()
{
   
    var a1 = document.getElementById("a1box");
    var an = document.getElementById("anbox");
    var n = document.getElementById("nbox");
    var d = document.getElementById("dbox");
    
    a1.style.display = "inline";
    an.style.display = "inline";
    n.style.display = "inline";
    d.style.display = "inline";
    
    an.style.display = 'inline'
    n.style.display = "none";
    
    
    
}

// response to when d radio button is pressed
function solve_d()
{
   
    var a1 = document.getElementById("a1box");
    var an = document.getElementById("anbox");
    var n = document.getElementById("nbox");
    var d = document.getElementById("dbox");
    
       
    a1.style.display = "inline";
    an.style.display = "inline";
    n.style.display = "inline";
    d.style.display = "inline";
    
            an.style.display = 'inline'
            d.style.display = "none";

}

// response to when an radio button is pressed
function solve_an()
{
    var a1 = document.getElementById("a1box");
    var an = document.getElementById("anbox");
    var n = document.getElementById("nbox");
    var d = document.getElementById("dbox");
    
    a1.style.display = "inline";
    an.style.display = "inline";
    n.style.display = "inline";
    d.style.display = "inline";
    
    an.style.display = 'none';
   
}

